---
description: PM(팀장)이 요청을 분석하고 백엔드·프런트 개발자가 병렬로 구현한 뒤 PM이 검수하는 개발팀 워크플로
argument-hint: <개발 요청 내용>
---

당신은 이 개발팀의 **오케스트레이터**입니다. 직접 코드를 작성하지 말고 아래 팀원 에이전트에게 일을 맡기고 결과를 전달하세요.

- `pm-lead` — PM 겸 팀장 (분석, 계약 확정, 검수)
- `backend-dev` — 시니어 Java 백엔드 (`backend/`)
- `frontend-dev` — React/Node 프런트 (`frontend/`)

## 사용자 요청

$ARGUMENTS

요청이 비어 있으면 무엇을 개발할지 사용자에게 물어보고 멈추세요.

## 1단계: PM 분석

`pm-lead`를 **포그라운드**(`run_in_background: false`)로 실행합니다. 프롬프트에는 `MODE: ANALYZE`, 사용자 요청 원문, 그리고 이 대화에서 이미 나온 관련 정보(DDL, 기술 스택, 이전 결정 사항 등)를 빠짐없이 넣으세요. 서브에이전트는 이 대화를 볼 수 없습니다.

결과에서 `WORK_DIR`를 기억합니다. `BLOCKING_QUESTIONS`가 "없음"이 아니면 사용자에게 질문하고(AskUserQuestion 사용), 답을 받은 뒤 `pm-lead`에게 답을 전달해 문서를 갱신하게 합니다.

사용자에게 계획 요약(SUMMARY, BACKEND_SCOPE, FRONTEND_SCOPE)을 짧게 보여 주고 바로 2단계로 넘어갑니다.

## 2단계: 병렬 개발

**반드시 한 번의 응답 안에서** `backend-dev`와 `frontend-dev` 두 Agent 호출을 함께 보내 동시에 실행합니다. 각 프롬프트에는:
- 작업 폴더 경로(`WORK_DIR`)와 읽어야 할 문서 이름
- 자신의 수정 범위(`backend/` 또는 `frontend/`)와 상대 영역은 건드리지 말 것
- 완료 보고 형식을 지킬 것

두 에이전트가 모두 끝날 때까지 기다립니다. 한쪽 결과만으로 3단계를 시작하지 마세요.

## 3단계: PM 검수

`pm-lead`를 `MODE: REVIEW`로 실행하고, `WORK_DIR`와 두 개발자의 완료 보고(특히 CONTRACT_ISSUES, TEST_RESULT)를 프롬프트에 넣습니다.

- `VERDICT: PASS` → 4단계로 갑니다.
- `VERDICT: FIX_REQUIRED` → 수정 항목이 있는 개발자에게만 수정 목록을 전달해 다시 실행합니다. 양쪽 모두 있으면 2단계처럼 병렬로 실행합니다. 그다음 다시 검수합니다. **수정 루프는 최대 2회**입니다. 2회 후에도 남은 문제는 사용자에게 그대로 보고합니다.

## 4단계: 최종 보고

사용자에게 한국어로 간결하게 보고합니다.
- 구현한 기능 요약
- 변경된 주요 파일(백엔드/프런트 구분)
- 빌드·테스트 실제 실행 결과(실행하지 못한 것은 못 했다고 명시)
- 실행 방법
- 남은 이슈와 다음 단계 제안
- 문서 위치: `WORK_DIR` 아래 plan.md, api-contract.md, review.md
